import logging
import os
import azure.functions as func


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    license = """
    VulnFunction
    Copyright (C) 2023 Cody Martin

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
    """
    with open('/tmp/license.txt', 'w') as outfile:
        outfile.write(license)

    f = req.params.get('file')
    p = req.params.get('path')
    
    if f:
        infile = open(f)
        content = infile.read()
        infile.close()
        return func.HttpResponse(content)
    elif p:
        output = ''
        entries = os.scandir(p)
        for entry in entries:
            output = output + entry.name + '\n'
        return func.HttpResponse(output)
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a file in the query string or in the request body for a personalized response.",
             status_code=200
        )
