import logging
import os
import azure.functions as func


def main(req: func.HttpRequest) -> func.HttpResponse:
    
    url = req.params.get('url')
    
    if url:
        command = f'/usr/bin/curl {url}'
        logging.info('1')
        output = os.popen(command)
        logging.info('2')
        return func.HttpResponse(str(output.read()))
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a url in the query string or in the request body for a personalized response.",
             status_code=200
        )